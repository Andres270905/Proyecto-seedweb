import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" type="image/png" href="img/Sin título.png">
        <title>Inicio de Sesión - Portal Agrícola</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #E8FFEA;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
        .login-container {
            background-color: #B4FED0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #000000;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #B4FED0;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #B4FED0;
            color: rgb(0, 0, 0);
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #E8FFEA;
        }
        .si{
            text-align: center;
        }
        </style>
</head>
<body>
<div class="login-container">
        <center><img src="img/Logo_2.png" width="300" ></center>
        <h2>Registrate</h2>
        <form action="/dashboard" method="post">
            <input type="text" name="username" placeholder="Ingrese un Usuario" required>
            <input type="text" name="text" placeholder="Cedula de Ciudadania" required>
            <input type="text" name="text" placeholder="Número de Telefeno" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="text" placeholder="Cree su Contraseña" required>
            <input type="submit" value="Registrarse">
        </form>
    </div>
</body>
</html>
    </div>
  )
}

export default App
