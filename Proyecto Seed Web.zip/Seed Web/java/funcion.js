document.getElementById('forgot-password').addEventListener('submit', function(event) {
    event.preventDefault();  // Evita el envío normal del formulario

    const email = document.getElementById('forgot-email').value;

    // Validación de correo electrónico
    if (!email) {
        alert('Por favor ingresa tu correo electrónico.');
        return;
    }

    // Deshabilitar el botón para evitar múltiples envíos
    const button = event.target.querySelector('button[type="submit"]');
    button.disabled = true;
    button.innerText = 'Enviando...';

    // Crear el objeto con el correo electrónico
    const requestData = {
        email: email
    };

    // Enviar la solicitud al backend (FastAPI)
    fetch('http://127.0.0.1:8000/forgot-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        if (response.ok) {
            return response.json(); // Parsear la respuesta en JSON si la respuesta es exitosa
        } else {
            throw new Error('Hubo un error al enviar el correo.');
        }
    })
    .then(data => {
        // Aquí se maneja la respuesta del backend
        if (data.mensaje === 'Correo de recuperación enviado exitosamente') {
            alert('Revisa tu correo electrónico para el enlace de recuperación.');
            // Puedes redirigir al usuario al inicio de sesión o mostrar un mensaje
        } else {
            alert('Hubo un error al enviar el correo. Intenta nuevamente.');
        }
    })
    .catch(error => {
        console.error('Error al enviar correo:', error);
        alert('Error al enviar el correo. Intenta nuevamente.');
    })
    .finally(() => {
        // Rehabilitar el botón después de la solicitud
        button.disabled = false;
        button.innerText = 'Enviar enlace de recuperación';
    });
});



// Función para mostrar el formulario de registro y ocultar el de inicio de sesión
function showRegister() {
    document.getElementById('login-form').classList.remove('active'); // Oculta el formulario de login
    document.getElementById('register-form').classList.add('active');  // Muestra el formulario de registro
}

// Función para mostrar el formulario de inicio de sesión y ocultar el de registro
function showLogin() {
    document.getElementById('register-form').classList.remove('active'); // Oculta el formulario de registro
    document.getElementById('forgot-password-form').classList.remove('active'); // Oculta el formulario de recuperación de contraseña
    document.getElementById('login-form').classList.add('active'); // Muestra el formulario de login
}

// Función para mostrar el formulario de "Olvidaste tu contraseña"
function showForgotPassword() {
    document.getElementById('login-form').classList.remove('active'); // Oculta el formulario de login
    document.getElementById('forgot-password-form').classList.add('active'); // Muestra el formulario de recuperación de contraseña
}

// Validación del formulario de inicio de sesión
document.getElementById('login').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // Validación de campos vacíos
    if (!email || !password) {
        if (!email) {
            showError('Por favor ingresa tu correo electrónico.');
        } else if (!password) {
            showError('Por favor ingresa tu contraseña.');
        }
        return;  // Salir de la función si falta algún campo
    }

    // Deshabilitar el botón de envío para prevenir múltiples envíos
    const loginButton = document.querySelector("button[type='submit']");
    loginButton.disabled = true;
    loginButton.innerText = 'Cargando...';  // Cambiar el texto del botón

    // Realizar la solicitud al backend para verificar las credenciales
    const loginData = {
        email: email,
        contrasena: password  // Asegúrate de enviar 'contrasena' como clave (de acuerdo al backend)
    };

    fetch('http://127.0.0.1:8000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(loginData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(errorData => {
                throw new Error(`Error: ${errorData.detail || response.statusText}`);
            });
        }
        return response.json();  // Parsear la respuesta a JSON si la respuesta es exitosa
    })
    .then(data => {
        console.log("Respuesta del servidor:", data);  // Imprimir los datos que devuelve el backend

        if (data.mensaje === 'Inicio de sesión exitoso') {
            // Almacenar el token JWT en localStorage o cookies (si estás usando JWT)
            // localStorage.setItem('access_token', data.access_token);
            
            // Redirigir a otra página (por ejemplo, dashboard)
            window.location.href = 'productos.html';  // Cambiar la URL de redirección según sea necesario
        }
    })
    .catch(error => {
        console.error('Error al iniciar sesión:', error);
        showError('Contraseña o correo electrónico inválidos.');
    })
    .finally(() => {
        // Rehabilitar el botón después de la solicitud
        loginButton.disabled = false;
        loginButton.innerText = 'Iniciar sesión';  // Restaurar el texto del botón
    });
});

// Función para mostrar mensajes de error
function showError(message) {
    const errorMessageDiv = document.getElementById('error-message');
    errorMessageDiv.innerText = message;
    errorMessageDiv.style.display = 'block';  // Mostrar el mensaje de error
}


// Función que se ejecuta cuando se envía el formulario de registro
document.getElementById('register').addEventListener('submit', function(event) {
    event.preventDefault();  // Evitar que el formulario se envíe de forma predeterminada

    // Obtener los valores de los campos de entrada
    const identificacion = document.getElementById('register-identif').value;
    const nombre = document.getElementById('register-nombre').value;
    const apellido = document.getElementById('register-apellido').value;
    const telefono = document.getElementById('register-telefono').value;
    const direccion = document.getElementById('register-direccion').value;
    const email = document.getElementById('register-email').value;
    const tipo_usuario = document.getElementById('register-tipo').value;
    console.log(tipo_usuario);  // Esto imprimirá 'vendedor' o 'comprador' dependiendo de la selección del usuario
    const password = document.getElementById('register-password').value;

    // Verificar que los campos no estén vacíos
    if (!nombre || !apellido || !telefono || !direccion || !email || !password) {
        alert('Por favor ingresa todos los campos.');
        return;  // Detener la ejecución si falta algún campo
    }

    // Crear el objeto data con los valores del formulario
    const data = {
        id_usuario: identificacion,
        nombre_usuario: nombre,
        apellido_usuario: apellido,
        telefono_usuario: telefono,
        direccion: direccion,
        email: email,
        tipo_usuario: tipo_usuario,
        contrasena: password
    };

    // Llamar a la función postData para enviar los datos
    postData(data);
});

// Función para enviar los datos al servidor
function postData(data) {
    // Realizar la solicitud fetch al servidor
    fetch('http://127.0.0.1:8000/usuario', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',         // Esto indica que esperamos una respuesta JSON
            'Content-Type': 'application/json'    // Esto indica que estamos enviando JSON
        },
        body: JSON.stringify(data)  // Convertir el objeto 'data' en JSON
    })
    .then(response => {
        // Verificar si la respuesta es exitosa
        if (!response.ok) {
            throw new Error(`Error en la respuesta del servidor: ${response.statusText}`);
        }
        return response.json();  // Convertir la respuesta a JSON
    })
    .then(data => {
        console.log('Respuesta del servidor:', data);
        
        // Si el registro es exitoso, mostrar el mensaje y cambiar al formulario de login
        alert('Registro exitoso. Ahora puedes iniciar sesión.');
        showLogin(); // Llamada a la función para mostrar el formulario de login
    })
    .catch(error => {
        console.log(JSON.stringify(data));
        console.error('Error al registrar:', error);
        alert('Hubo un problema con el registro. Intenta de nuevo.');
    });
}

// Función para mostrar el formulario de login
function showLogin() {
    document.getElementById('register-form').classList.remove('active');
    document.getElementById('forgot-password-form').classList.remove('active');
    document.getElementById('login-form').classList.add('active');
}

// Inicialmente se muestra el formulario de login
document.getElementById('login-form').classList.add('active');
