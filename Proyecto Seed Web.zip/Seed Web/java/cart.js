let cart = [];  // Carrito de productos
const cartCount = document.getElementById('cart-count'); // Contador de artículos en el carrito
const cartSection = document.getElementById('cart');  // Sección del carrito
const cartItemsList = document.getElementById('cart-items');  // Lista de artículos en el carrito
const cartTotal = document.getElementById('cart-total');  // Total del carrito

const products = document.querySelectorAll('.product');

// Añadir evento a los botones de "Añadir al carrito"
products.forEach(product => {
    const addToCartButton = product.querySelector('.add-to-cart');
    const productId = product.getAttribute('data-id');
    const productPrice = parseInt(product.querySelector('p').innerText.replace('Precio: $', ''));  // Redondear el precio a entero
    const productImage = product.querySelector('img').src;  // Obtener la URL de la imagen

    addToCartButton.addEventListener('click', () => {
        addToCart(productId, productPrice, productImage);  // Pasar también la URL de la imagen
    });
});

// Función para añadir productos al carrito
function addToCart(id, price, image) {
    // Verificar si el producto ya está en el carrito
    const existingProductIndex = cart.findIndex(item => item.id === id);
    if (existingProductIndex !== -1) {
        cart[existingProductIndex].quantity++;
    } else {
        cart.push({ id, price, image, quantity: 1 });
    }
    
    updateCartView();  // Actualizamos la vista del carrito
}

// Función para actualizar la vista del carrito
function updateCartView() {
    // Actualizar el contador de artículos en el carrito
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.innerText = `${totalItems} artículo${totalItems === 1 ? '' : 's'}`;
    
    // Mostrar u ocultar la sección del carrito
    cartSection.style.display = cart.length > 0 ? 'block' : 'none';

    // Limpiar la lista de productos en el carrito
    cartItemsList.innerHTML = '';

    let total = 0;
    // Mostrar cada producto del carrito
    cart.forEach(item => {
        total += item.price * item.quantity;  // Mantener la multiplicación con enteros
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <div>
                <img src="${item.image}" alt="${item.id}" style="width: 50px; height: 50px; margin-right: 10px;">
                Producto ${item.id} - $${item.price} x ${item.quantity}
            </div>
            <button class="remove-item" data-id="${item.id}">Eliminar</button>
        `;
        cartItemsList.appendChild(listItem);
    });

    // Actualizar el total del carrito con números enteros
    cartTotal.innerText = `Total: $${total}`;

    // Añadir evento a los botones de eliminar
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', (event) => {
            const productId = event.target.getAttribute('data-id');
            removeFromCart(productId);  // Llamar a la función para eliminar el producto
        });
    });
}

// Función para eliminar un producto del carrito
function removeFromCart(id) {
    const productIndex = cart.findIndex(item => item.id === id);
    if (productIndex !== -1) {
        cart.splice(productIndex, 1);  // Eliminar el producto
    }
    updateCartView();  // Actualizar la vista del carrito
}

// Acción de checkout (para demo, no hace nada)
document.getElementById('checkout').addEventListener('click', () => {
    alert('Proceso de pago iniciado');
});
