from fastapi import FastAPI, HTTPException, Depends, status
from conexion_db import crear_conexion
from models import Usuario, Producto, Factura, Mercancia, metodo_envio, met_pago, Detalle_Factura, LoginRequest, ForgotPasswordRequest
from typing import List
from datetime import datetime, time, timedelta
import mysql.connector
from typing import Optional
import bcrypt
import jwt
from models import BaseModel
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from passlib.context import CryptContext

app = FastAPI()

# Configuración de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permite todas las solicitudes de cualquier origen (también puedes especificar dominios específicos)
    allow_credentials=True,
    allow_methods=["*"],  # Permite todos los métodos HTTP (GET, POST, etc.)
    allow_headers=["*"],  # Permite todos los encabezados
)



def ejecutar_consulta(query: str, params: tuple = ()):
    conexion = mysql.connector.connect(host='localhost', database='seedweb', user='root', password='')
    if conexion is None:
        raise HTTPException(status_code=500, detail="Error al conectar a la base de datos")
    
    cursor = conexion.cursor(dictionary=True)
    try:
        cursor.execute(query, params)
        
        # Si es una consulta de modificación (INSERT, UPDATE, DELETE, etc.), realizamos commit
        if query.strip().upper().startswith(("INSERT", "UPDATE", "DELETE")):
            conexion.commit()
            return cursor
        
        # Si es una consulta de lectura (SELECT), procesamos los resultados
        if query.strip().upper().startswith("SELECT"):
            results = cursor.fetchall()
            return results
        
    except mysql.connector.Error as e:
        conexion.rollback()
        raise HTTPException(status_code=500, detail=f"Error al ejecutar la consulta: {e}")
    finally:
        cursor.close()
        conexion.close()


#####      USUARIO      #####

@app.get("/usuarios", tags=['Usuarios'])
def obtener_usuarios():
    query = "SELECT * FROM usuario"
    usuarios = ejecutar_consulta(query)  # Usamos ejecutar_consulta directamente
    return {"usuarios": usuarios}  # Retornamos los usuarios encontrados

#  REGISTRO

@app.post("/usuario", tags=['Usuarios'])  
def crear_usuario(usuario: Usuario):
    # Verificar si el id_usuario ya existe
    query_check = "SELECT COUNT(*) FROM usuario WHERE id_usuario = %s"
    params_check = (usuario.id_usuario,)
    result = ejecutar_consulta(query_check, params_check)
    
    # Si el id_usuario ya existe, no permitimos la inserción
    if result[0]["COUNT(*)"] > 0:
        raise HTTPException(status_code=400, detail=f"El id_usuario {usuario.id_usuario} ya existe.")


    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    hashed_password = pwd_context.hash(usuario.contrasena)
    
    # Si no existe, proceder con la inserción
    query_insert = """INSERT INTO usuario (id_usuario, nombre_usuario, apellido_usuario, telefono_usuario, direccion, email, tipo_usuario, contrasena) 
                      VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"""
    params_insert = (
        usuario.id_usuario,  
        usuario.nombre_usuario, 
        usuario.apellido_usuario, 
        usuario.telefono_usuario,
        usuario.direccion, 
        usuario.email, 
        usuario.tipo_usuario.value,
        hashed_password
    )

    # Ejecutamos la consulta de inserción
    resultado = ejecutar_consulta(query_insert, params_insert)  # Aquí se espera un mensaje de éxito
    return {"mensaje": "Usuario creado exitosamente", "usuario": usuario.nombre_usuario}



# LOGIN 


# Endpoint para el login
@app.post("/login", tags=['Inicio Sesion'])
async def login(request: LoginRequest):
    # Accede a los datos del cuerpo de la solicitud
    email = request.email
    contrasena = request.contrasena

    # Obtén el hash de la contraseña del usuario desde la base de datos
    query = "SELECT contrasena FROM usuario WHERE email = %s"
    params = (email,)
    result = ejecutar_consulta(query, params)
    
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario no encontrado")
    
    hash_almacenado = result[0]["contrasena"]
    
    # Verifica la contraseña ingresada con el hash almacenado
    if not verificar_contrasena(contrasena, hash_almacenado):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Contraseña incorrecta")
    
    # Si la contraseña es correcta, puedes generar un token JWT o lo que necesites para el login
    return {"mensaje": "Inicio de sesión exitoso"}

# OLVIDE CONTRASEÑA


from email.mime.text import MIMEText
import smtplib
from uuid import uuid4
# Función para enviar el correo de recuperación
def send_reset_password_email(email: str, link: str):
    msg = MIMEText(f'Para restablecer tu contraseña, haz clic en el siguiente enlace: {link}')
    msg['Subject'] = 'Recuperación de Contraseña'
    msg['From'] = 'sedweb40@gmail.com'
    msg['To'] = email

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()  # Asegura la conexión con TLS
            server.login('sedweb40@gmail.com', 'hykq wuat hxpg jnsv')  # Asegúrate de que la contraseña sea correcta
            server.sendmail(msg['From'], [msg['To']], msg.as_string())
            print("Correo enviado exitosamente.")
    except Exception as e:
        print(f"Error al enviar el correo: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error al enviar el correo")
    

# Configura el contexto para el hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Función para verificar el hash de la contraseña
def verificar_contrasena(contraseña_ingresada: str, hash_almacenado: str) -> bool:
    return pwd_context.verify(contraseña_ingresada, hash_almacenado)

@app.post("/forgot-password", tags=["Recuperación Contraseña"])
async def forgot_password(request: ForgotPasswordRequest):
    email = request.email

    # Verificar si el email existe en la base de datos
    query = "SELECT email FROM usuario WHERE email = %s"
    params = (email,)
    result = ejecutar_consulta(query, params)  # Asegúrate de que esta función esté bien definida
    
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario no encontrado")

    # Generar un token único para el enlace de recuperación
    reset_token = str(uuid4())

    # Crear el enlace de recuperación (puedes cambiarlo por un enlace real)
    reset_link = f"http://localhost:8000/reset-password/{reset_token}"

    # Enviar el correo
    send_reset_password_email(email, reset_link)

    return {"mensaje": "Correo de recuperación enviado exitosamente"}

@app.delete("/usuario/{id_usuario}", tags=["Usuarios"])
def eliminar_usuario(id_usuario: int):
    # Consulta para eliminar al usuario
    query = "DELETE FROM usuario WHERE id_usuario = %s"
    
    # Ejecuta la consulta
    cursor = ejecutar_consulta(query, (id_usuario,))
    
    # Verifica si se ha eliminado alguna fila
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    return {"mensaje": f"Usuario con id {id_usuario} eliminado exitosamente"}


@app.put("/usuario/{id_usuario}", tags=["Usuarios"])
def actualizar_usuario(id_usuario: int, usuario: Usuario):
    # Verificar si el usuario existe
    query_check = "SELECT COUNT(*) FROM usuario WHERE id_usuario = %s"
    params_check = (id_usuario,)
    result = ejecutar_consulta(query_check, params_check)

    # Si el usuario no existe, lanzamos un error
    if result[0]["COUNT(*)"] == 0:
        raise HTTPException(status_code=404, detail=f"Usuario con id {id_usuario} no encontrado")

    # Crear la consulta para actualizar los datos del usuario
    query_update = """UPDATE usuario 
                      SET nombre_usuario = %s, apellido_usuario = %s, telefono_usuario = %s, direccion = %s, 
                          email = %s, tipo_usuario = %s 
                      WHERE id_usuario = %s"""
    params_update = (
        usuario.nombre_usuario, 
        usuario.apellido_usuario, 
        usuario.telefono_usuario,
        usuario.direccion, 
        usuario.email, 
        usuario.tipo_usuario.value,  # Usamos .value para obtener el valor real del Enum
        id_usuario  # Usamos el id_usuario en la condición WHERE
    )

    # Ejecutar la consulta de actualización
    ejecutar_consulta(query_update, params_update)

    return {"mensaje": f"Usuario con id {id_usuario} actualizado exitosamente", "usuario": usuario}

#####          PRODUCTOS          #####



@app.get("/productos", tags=['Productos'])
def obtener_productos():
    query = "SELECT * FROM productos"
    productos = ejecutar_consulta(query)  # Usamos ejecutar_consulta directamente
    return {"productos": productos}  # Retornamos los productos encontrados


@app.post("/producto", tags=['Productos'])
def crear_producto(producto: Producto):
    # Verificar si el id_producto ya existe
    query_check = "SELECT COUNT(*) FROM productos WHERE id_producto = %s"
    params_check = (producto.id_producto,)
    result = ejecutar_consulta(query_check, params_check)
    
    # Si el id_producto ya existe, no permitimos la inserción
    if result[0]["COUNT(*)"] > 0:
        raise HTTPException(status_code=400, detail=f"El id_producto {producto.id_producto} ya existe.")
    
    # Si no existe, proceder con la inserción
    query_insert = """INSERT INTO productos (id_producto, nombre_producto, descripcion, precio_producto, categoria, disponible) 
                      VALUES (%s, %s, %s, %s, %s, %s)"""
    params_insert = (
        producto.id_producto,  
        producto.nombre_producto, 
        producto.descripcion, 
        producto.precio_producto,
        producto.categoria.value,  # Usamos .value para obtener el valor del Enum
        producto.disponible
    )

    # Ejecutamos la consulta de inserción
    resultado = ejecutar_consulta(query_insert, params_insert)  # Aquí se espera un mensaje de éxito
    return {"mensaje": "Producto creado exitosamente", "producto": producto}


@app.delete("/producto/{id_producto}", tags=["Productos"])
def eliminar_producto(id_producto: int):
    # Consulta para eliminar el producto
    query = "DELETE FROM productos WHERE id_producto = %s"
    
    # Ejecuta la consulta
    cursor = ejecutar_consulta(query, (id_producto,))
    
    # Verifica si se ha eliminado alguna fila
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    
    return {"mensaje": f"Producto con id {id_producto} eliminado exitosamente"}

@app.put("/producto/{id_producto}", tags=["Productos"])
def actualizar_producto(id_producto: int, producto: Producto):
    # Verificar si el producto existe
    query_check = "SELECT COUNT(*) FROM productos WHERE id_producto = %s"
    params_check = (id_producto,)
    result = ejecutar_consulta(query_check, params_check)

    # Si el producto no existe, lanzamos un error
    if result[0]["COUNT(*)"] == 0:
        raise HTTPException(status_code=404, detail=f"Producto con id {id_producto} no encontrado")

    # Crear la consulta para actualizar los datos del producto
    query_update = """UPDATE productos 
                      SET nombre_producto = %s, descripcion = %s, precio_producto = %s, categoria = %s, 
                          disponible = %s 
                      WHERE id_producto = %s"""
    params_update = (
        producto.nombre_producto, 
        producto.descripcion, 
        producto.precio_producto,
        producto.categoria.value,  # Usamos .value para obtener el valor real del Enum
        producto.disponible,
        id_producto  # Usamos el id_producto en la condición WHERE
    )

    # Ejecutar la consulta de actualización
    ejecutar_consulta(query_update, params_update)

    return {"mensaje": f"Producto con id {id_producto} actualizado exitosamente", "producto": producto}


#####           MERCANCIA          #####


@app.get("/mercancia", tags=['Mercancia'])
def obtener_mercancia():
    query = "SELECT * FROM mercancia"
    mercancia = ejecutar_consulta(query)  # Usamos ejecutar_consulta directamente
    return {"mercancia": mercancia}  # Retornamos la mercancia encontrada



#####           METODO_ENVIO         #####


@app.get("/metodos_envio", tags=['Metodo Envio'])
def obtener_metodos_envio():
    query = "SELECT * FROM metodo_envio"
    metodos_envio = ejecutar_consulta(query)
    return {"metodos_envio": metodos_envio}


#####            FACTURA             #####




@app.get("/facturas", response_model=List[Factura], tags=["Facturas"])
async def obtener_facturas():
    query = "SELECT * FROM factura"
    facturas_db = ejecutar_consulta(query)  # Ejecutar la consulta para obtener facturas

    # Si no hay resultados, devolvemos una respuesta vacía
    if not facturas_db:
        raise HTTPException(status_code=404, detail="No se encontraron facturas.")
    
    # Convertir el valor de 'hora' de timedelta a time
    facturas = []
    for factura in facturas_db:
        # Verificamos si 'hora' es un tipo timedelta
        if isinstance(factura['hora'], timedelta):
            # Convertir timedelta a time (en caso de que sea un timedelta)
            total_seconds = factura['hora'].total_seconds()
            factura['hora'] = (datetime.min + timedelta(seconds=total_seconds)).time()

        # Convertir el registro a un modelo Pydantic
        facturas.append(Factura(**factura))  # Crear el objeto Pydantic

    return facturas



#####        DETALLE_FACTURA           #####

@app.get("/detalle_factura", response_model=List[Detalle_Factura], tags=["Detalle Factura"])
def obtener_detalle_factura():
    query = """
        SELECT df.id_detalle_factura, df.id_mercancia, df.id_factura, 
               p.nombre_producto AS nombre_mercancia, f.fecha AS fecha_factura
        FROM detalle_de_factura df
        JOIN mercancia m ON df.id_mercancia = m.id_mercancia
        JOIN productos p ON m.id_producto = p.id_producto  -- Aquí se hace el JOIN con la tabla productos
        JOIN factura f ON df.id_factura = f.id_factura
    """
    
    # Ejecutamos la consulta
    detalles = ejecutar_consulta(query)
    
    # Si no se encontraron detalles, respondemos con un error 404
    if not detalles:
        raise HTTPException(status_code=404, detail="No se encontraron detalles de factura.")
    
    return detalles









