import mysql.connector
from mysql.connector import Error

def crear_conexion():
    """Crea una conexión con la base de datos MySQL y la retorna si es exitosa."""
    conexion = None  # Definimos la variable de la conexión fuera del bloque try
    try:
        print("Intentando conectar a la base de datos...")
        # Establecer la conexión a la base de datos
        conexion = mysql.connector.connect(
            host="localhost",        # Dirección del servidor MySQL (usualmente localhost)
            user="root",             # Tu usuario de MySQL
            password="",             # Cambia esto por la contraseña de tu base de datos
            database="seedweb"       # El nombre de tu base de datos
        )

        # Verificar si la conexión fue exitosa
        if conexion.is_connected():
            print("Conexión exitosa a la base de datos")
            
            # Hacer una consulta simple para verificar que la base de datos está activa
            cursor = conexion.cursor()
            cursor.execute("SELECT DATABASE();")  # Consulta para obtener el nombre de la base de datos
            db = cursor.fetchone()  # Obtener el nombre de la base de datos
            print(f"Conectado a la base de datos: {db[0]}")  # Imprimir el nombre de la base de datos
            cursor.close()
            
            return conexion  # Retorna la conexión para ser utilizada fuera de esta función
        else:
            print("Error al conectar a la base de datos")
            return None
    except Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None

def cerrar_conexion(conexion):
    """Cierra la conexión a la base de datos si está abierta."""
    if conexion and conexion.is_connected():
        conexion.close()
        print("Conexión cerrada correctamente.")

# Ejemplo de uso:
conexion = crear_conexion()



